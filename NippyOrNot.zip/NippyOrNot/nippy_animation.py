"""
NIPPY Animation Module
A self-contained Pygame module that animates the word 'NIPPY' based on temperature and wind conditions.
Can be run standalone or imported into an existing Pygame application.
"""

import pygame
import math
import sys


class NippyAnimator:
    """
    Animates the word 'NIPPY' filling letters based on nippiness score.
    Score ranges from 1-5 based on temperature and wind speed.
    """
    
    # Clothing suggestions for each nippiness level
    CLOTHING_SUGGESTIONS = {
        1: "It is quite pleasant 🌤, a T-shirt or light layers like linen or cotton will do",
        2: "Mild enough 🙂, a jumper or light jacket should be fine",
        3: "Getting nippy 🧥, a coat or thick jacket is recommended",
        4: "Properly chilly 🧣, wear a warm coat and scarf to stay cosy",
        5: "Bitterly cold ❄️, full winter gear including hat, gloves and scarf is advised"
    }
    
    # Color scheme
    BG_COLOR = (20, 20, 30)          # Dark background
    LETTER_EMPTY = (60, 60, 80)      # Empty letter outline
    LETTER_FILLED = (100, 200, 255)  # Bright cyan for filled letters
    TEXT_COLOR = (200, 200, 220)     # Light gray for text
    
    def __init__(self, width=800, height=600):
        """
        Initialize the NIPPY animator.
        
        Args:
            width: Surface width in pixels
            height: Surface height in pixels
        """
        self.width = width
        self.height = height
        self.surface = pygame.Surface((width, height))
        
        # Animation state
        self.current_fill = 0.0  # Number of letters filled (0.0 to 5.0)
        self.target_fill = 0.0   # Target fill level based on nippiness score
        self.animation_speed = 2.0  # Letters per second
        
        # Score and conditions
        self.nippiness_score = 0
        self.temperature = 20.0
        self.wind_speed = 0.0
        
        # Font setup (will be initialized in setup())
        self.title_font = None
        self.text_font = None
        
    def setup(self):
        """Initialize fonts and other resources that require Pygame to be initialized."""
        pygame.font.init()
        self.title_font = pygame.font.Font(None, 120)
        self.text_font = pygame.font.Font(None, 32)
        
    def calculate_nippiness(self, temperature, wind_speed):
        """
        Calculate nippiness score (1-5) based on temperature and wind speed.
        Uses wind-adjusted "feels-like" temperature formula.
        
        Args:
            temperature: Temperature in Celsius
            wind_speed: Wind speed in km/h
            
        Returns:
            Integer score from 1 (pleasant) to 5 (very nippy)
        """
        # Wind chill adjustment (simplified formula)
        # More wind = feels colder
        wind_factor = 0.6 * wind_speed / 10.0  # Each 10 km/h adds ~0.6°C chill
        feels_like = temperature - wind_factor
        
        # Score thresholds based on feels-like temperature
        if feels_like > 20:
            return 1  # Pleasant, t-shirt weather
        elif feels_like > 15:
            return 2  # Mild, need a jumper
        elif feels_like > 10:
            return 3  # Cool, need a coat
        elif feels_like > 5:
            return 4  # Cold, warm coat and scarf
        else:
            return 5  # Very cold, full winter gear
    
    def set_conditions(self, temperature, wind_speed):
        """
        Update weather conditions and calculate new nippiness score.
        
        Args:
            temperature: Temperature in Celsius
            wind_speed: Wind speed in km/h
        """
        self.temperature = temperature
        self.wind_speed = wind_speed
        self.nippiness_score = self.calculate_nippiness(temperature, wind_speed)
        self.target_fill = float(self.nippiness_score)
        
    def update(self, dt):
        """
        Update animation state.
        
        Args:
            dt: Delta time in seconds since last update
        """
        # Smoothly animate towards target fill level
        if self.current_fill < self.target_fill:
            self.current_fill += self.animation_speed * dt
            if self.current_fill > self.target_fill:
                self.current_fill = self.target_fill
        elif self.current_fill > self.target_fill:
            self.current_fill -= self.animation_speed * dt
            if self.current_fill < self.target_fill:
                self.current_fill = self.target_fill
    
    def draw(self):
        """
        Draw the NIPPY animation to the surface.
        
        Returns:
            pygame.Surface with the rendered animation
        """
        # Clear background
        self.surface.fill(self.BG_COLOR)
        
        # Draw title "NIPPY" with progressive filling
        letters = ['N', 'I', 'P', 'P', 'Y']
        letter_width = 100
        total_width = letter_width * len(letters)
        start_x = (self.width - total_width) // 2
        y_pos = self.height // 3
        
        for i, letter in enumerate(letters):
            x_pos = start_x + i * letter_width
            
            # Determine fill level for this letter
            fill_amount = max(0.0, min(1.0, self.current_fill - i))
            
            if fill_amount > 0:
                # Draw filled letter with glow effect
                color = self.LETTER_FILLED
                
                # Add pulsing effect to currently filling letter
                if 0 < fill_amount < 1.0:
                    pulse = (math.sin(pygame.time.get_ticks() / 200) + 1) / 2
                    brightness = 0.7 + 0.3 * pulse
                    color = tuple(int(c * brightness) for c in self.LETTER_FILLED)
                
                text_surface = self.title_font.render(letter, True, color)
            else:
                # Draw empty outline
                text_surface = self.title_font.render(letter, True, self.LETTER_EMPTY)
            
            # Center each letter
            text_rect = text_surface.get_rect(center=(x_pos + letter_width // 2, y_pos))
            self.surface.blit(text_surface, text_rect)
        
        # Draw current conditions
        y_offset = y_pos + 120
        
        # Temperature and wind info
        conditions_text = f"Temperature: {self.temperature:.1f}°C  |  Wind: {self.wind_speed:.1f} km/h"
        conditions_surface = self.text_font.render(conditions_text, True, self.TEXT_COLOR)
        conditions_rect = conditions_surface.get_rect(center=(self.width // 2, y_offset))
        self.surface.blit(conditions_surface, conditions_rect)
        
        # Nippiness score
        y_offset += 50
        score_text = f"Nippiness Score: {self.nippiness_score}/5"
        score_surface = self.text_font.render(score_text, True, self.LETTER_FILLED)
        score_rect = score_surface.get_rect(center=(self.width // 2, y_offset))
        self.surface.blit(score_surface, score_rect)
        
        # Clothing suggestion
        y_offset += 60
        suggestion_text = f"Recommended: {self.CLOTHING_SUGGESTIONS.get(self.nippiness_score, 'N/A')}"
        suggestion_surface = self.text_font.render(suggestion_text, True, (150, 255, 150))
        suggestion_rect = suggestion_surface.get_rect(center=(self.width // 2, y_offset))
        self.surface.blit(suggestion_surface, suggestion_rect)
        
        # Draw progress indicator
        self._draw_progress_bar(y_offset + 80)
        
        return self.surface
    
    def _draw_progress_bar(self, y_pos):
        """
        Draw a visual progress bar showing fill level.
        
        Args:
            y_pos: Y position for the progress bar
        """
        bar_width = 400
        bar_height = 30
        x_pos = (self.width - bar_width) // 2
        
        # Draw background
        pygame.draw.rect(self.surface, self.LETTER_EMPTY, 
                        (x_pos, y_pos, bar_width, bar_height), border_radius=15)
        
        # Draw filled portion
        fill_width = int((self.current_fill / 5.0) * bar_width)
        if fill_width > 0:
            pygame.draw.rect(self.surface, self.LETTER_FILLED,
                           (x_pos, y_pos, fill_width, bar_height), border_radius=15)
        
        # Draw segment markers (5 segments)
        for i in range(1, 5):
            marker_x = x_pos + int((i / 5.0) * bar_width)
            pygame.draw.line(self.surface, self.BG_COLOR,
                           (marker_x, y_pos), (marker_x, y_pos + bar_height), 3)


def run_standalone_demo():
    """
    Run a standalone demo of the NIPPY animator.
    Cycles through different weather conditions to demonstrate the animation.
    """
    pygame.init()
    
    # Create display
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("NIPPY Animation Demo")
    clock = pygame.time.Clock()
    
    # Create animator
    animator = NippyAnimator(800, 600)
    animator.setup()
    
    # Demo weather conditions to cycle through
    demo_conditions = [
        (25.0, 5.0),   # Pleasant: T-shirt weather
        (17.0, 10.0),  # Mild: Jumper needed
        (12.0, 15.0),  # Cool: Coat needed
        (7.0, 20.0),   # Cold: Warm coat + scarf
        (2.0, 25.0),   # Very cold: Full winter gear
    ]
    
    current_demo = 0
    demo_timer = 0
    demo_duration = 4.0  # Seconds per demo condition
    
    # Set initial conditions
    animator.set_conditions(*demo_conditions[0])
    
    # Instructions
    font = pygame.font.Font(None, 24)
    
    running = True
    while running:
        dt = clock.tick(60) / 1000.0  # Delta time in seconds
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE:
                    # Advance to next demo condition
                    current_demo = (current_demo + 1) % len(demo_conditions)
                    animator.set_conditions(*demo_conditions[current_demo])
                    demo_timer = 0
        
        # Auto-cycle through demo conditions
        demo_timer += dt
        if demo_timer >= demo_duration:
            current_demo = (current_demo + 1) % len(demo_conditions)
            animator.set_conditions(*demo_conditions[current_demo])
            demo_timer = 0
        
        # Update animation
        animator.update(dt)
        
        # Draw to screen
        surface = animator.draw()
        screen.blit(surface, (0, 0))
        
        # Draw instructions
        instructions = "Press SPACE to cycle conditions | ESC to quit | Auto-cycling every 4s"
        inst_surface = font.render(instructions, True, (150, 150, 150))
        inst_rect = inst_surface.get_rect(center=(400, 570))
        screen.blit(inst_surface, inst_rect)
        
        pygame.display.flip()
    
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    # Run standalone demo when executed directly
    run_standalone_demo()
