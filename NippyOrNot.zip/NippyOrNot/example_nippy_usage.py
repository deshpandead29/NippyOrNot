"""
Example: How to integrate NippyAnimator into an existing Pygame application
"""

import pygame
from nippy_animation import NippyAnimator


def main():
    """Example of using NippyAnimator in your own Pygame app."""
    pygame.init()
    
    # Your main display
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("My App with NIPPY Animation")
    clock = pygame.time.Clock()
    
    # Create the NIPPY animator
    nippy = NippyAnimator(800, 600)
    nippy.setup()
    
    # Set weather conditions (temperature in °C, wind in km/h)
    nippy.set_conditions(temperature=8.0, wind_speed=20.0)
    
    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
        
        # Update the animation
        nippy.update(dt)
        
        # Get the rendered surface and blit it to your screen
        nippy_surface = nippy.draw()
        screen.blit(nippy_surface, (0, 0))
        
        # You can draw other things on top or change conditions dynamically
        # Example: nippy.set_conditions(new_temp, new_wind)
        
        pygame.display.flip()
    
    pygame.quit()


if __name__ == "__main__":
    main()
