# Weather Travel Companion

## Overview

A weather-focused travel companion application called "NippyorNot" that helps users check weather conditions at their destinations and provides smart recommendations for travel essentials (umbrella, coat, water) based on real-time weather data. The app features location search with autocomplete, interactive TomTom maps, and weather comparisons between start and end destinations with day/night aware weather icons.

## User Preferences

Preferred communication style: Simple, everyday language.

## NIPPY Animation System

### Web Integration (React Component)

**Component:** `client/src/components/NippyAnimation.tsx`

A unified component that combines the NIPPY visualization with all travel recommendations:

**Features:**
- **Temperature-Based Color Gradient**: Smooth blended gradient flows across all letters from warm to cold
  - Starts at N: Gold/Yellow `rgb(255, 215, 0)` (warm)
  - Blends through: Orange-yellow → Light cyan → Blue
  - Ends at Y: Icy blue `rgb(59, 130, 246)` (cold)
  - Creates seamless color transition across the word NIPPY
- **Progressive Fill Animation**: Letters fill from bottom to top, creating a pouring effect with glow
- **Unified Recommendations**: Combines clothing, umbrella, and water in one text
- **Wind-Adjusted Score**: `feels_like = temp - (0.6 × wind/10)`, uses MAX of both locations
- **Smart Icons**: Shows relevant travel items (☂️🧥💧) based on conditions
- **Clothing Levels**:
  - Level 1: T-shirt and light layers (feels-like > 20°C)
  - Level 2: Jumper or light jacket (feels-like > 15°C)
  - Level 3: Coat or thick jacket (feels-like > 10°C)
  - Level 4: Warm coat and scarf (feels-like > 5°C)
  - Level 5: Winter coat, hat, gloves, and scarf (feels-like ≤ 5°C)

**Design Philosophy:**
- Single cohesive component (no redundant banners)
- Visual color feedback for temperature at a glance
- All recommendations in one natural sentence
- Considers conditions at BOTH start and end locations

### Python/Pygame Version (Standalone)

A separate Python module (`nippy_animation.py`) using the same scoring system:

**Features:**
- Self-contained Pygame surface for desktop applications
- Auto-cycling demo with multiple weather scenarios
- Bright cyan letters on dark background
- Importable: `from nippy_animation import NippyAnimator`

**Usage:**
- Standalone: `python nippy_animation.py` (demo mode)
- See `NIPPY_ANIMATION_README.md` for full API documentation

**Files:**
- `nippy_animation.py` - Main module
- `example_nippy_usage.py` - Integration example
- `NIPPY_ANIMATION_README.md` - Documentation
- `NIPPY_VISUAL_GUIDE.txt` - Visual reference

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18+ with TypeScript for type-safe component development
- Vite as the build tool and development server for fast hot module replacement
- Wouter for client-side routing (lightweight alternative to React Router)
- TanStack Query v5 for server state management and data fetching

**UI Component System**
- Radix UI primitives for accessible, unstyled component foundations
- shadcn/ui component library with "new-york" style configuration
- Tailwind CSS for utility-first styling with custom design tokens
- Class Variance Authority (CVA) for component variant management

**Design Philosophy**
- Notion-inspired minimal black/white aesthetic with clean, functional interface
- Citymapper-inspired layout with full-width map
- Generous whitespace and subtle interactions
- Inter font family for typography
- Custom color system using HSL with CSS variables for theme support
- No theme toggle (fixed light theme)

**State Management Strategy**
- Server state handled by TanStack Query with disabled auto-refetch
- Local UI state managed with React hooks
- Form state managed through React Hook Form with Zod validation
- Toast notifications for user feedback

### Backend Architecture

**Server Framework**
- Express.js with TypeScript running on Node.js
- ESM module system for modern JavaScript syntax
- Custom middleware for request logging and JSON parsing with raw body access

**Project Structure**
- Monorepo structure with shared code between client and server
- `/client` - React frontend application
- `/server` - Express backend with routes and storage layer
- `/shared` - Shared TypeScript types and schemas

**Storage Layer**
- Abstracted storage interface (IStorage) for flexible data persistence
- In-memory storage implementation (MemStorage) as default
- Designed for future database integration through storage interface

**API Design**
- RESTful API endpoints prefixed with `/api`
- Centralized route registration pattern
- Request/response logging middleware for debugging

### Data Storage Solutions

**Database Configuration**
- Drizzle ORM configured for PostgreSQL with Neon serverless driver
- Schema-first approach with TypeScript type inference
- Migration system using drizzle-kit
- Database schema defined in `/shared/schema.ts` for type sharing

**Current Schema**
- Users table with UUID primary keys, username/password fields
- Zod validation schemas for insert operations
- Type-safe database queries through Drizzle's query builder

**Session Management**
- connect-pg-simple configured for PostgreSQL-backed sessions
- Prepared for authentication implementation

### External Dependencies

**Weather Data Provider**
- Open-Meteo API for real-time weather data
- Weather data includes: temperature, feels-like, conditions, precipitation, humidity, wind speed, visibility, is_day
- Day/night aware weather emoji system (☀️ for day, 🌙 for night on clear weather)
- Supports weather code to emoji conversion for visual representation

**Geolocation Services**
- OpenStreetMap Nominatim API for location search and autocomplete
- Browser Geolocation API for current position detection
- Coordinate-based queries for weather data retrieval

**Mapping Library**
- TomTom Maps SDK for interactive map display
- WebGL-based rendering with graceful fallback
- API key securely provided via server endpoint (/api/config)
- Support for markers showing current location (blue), start/end destinations (black)
- Auto-fit bounds to show all markers
- Full-width edge-to-edge map layout (Citymapper-style)

**Third-Party UI Libraries**
- Lucide React for consistent iconography
- date-fns for date manipulation and formatting
- cmdk for command palette-style interfaces
- vaul for drawer/modal components
- embla-carousel-react for carousel functionality
- recharts for potential data visualization

**Development Tools**
- Replit-specific plugins for development environment integration
- Runtime error overlay for better debugging
- Cartographer and dev banner for Replit workspace integration

**Design Tokens**
- Custom CSS variables for consistent theming
- Hover and active state elevation utilities
- Border and shadow system for depth perception
- Responsive breakpoints at 768px for mobile/desktop split

### Core Features

**Saved Places**
- Save Home and Work locations via Settings dialog in top-left corner
- Settings button (⚙️) overlays the map for quick access
- LocationInput components for searching and saving locations:
  - Nominatim API autocomplete with search suggestions
  - Shows saved places at top of dropdown with icons (Home 🏠, Work 💼)
  - Ref-based search suppression prevents dropdown from blocking UI after selection
  - AbortController cancels stale fetch requests
- One location per tag enforcement (saving replaces existing)
- Quick access: Click saved places in From/To autocomplete dropdowns
- Delete saved places via trash button in settings
- Stores location name, tag, coordinates (latitude/longitude)
- In-memory storage (MemStorage) for saved places
- API endpoints: GET/POST/DELETE /api/saved-places
- Components: `SettingsDialog.tsx`, `LocationInput.tsx`

**Weather Recommendations (Unified in NIPPY Component)**
- **Prominent Rain Warning**: Large blue banner with Umbrella icon when rain is expected or precipitation > 40%
- **Gradient NIPPY Letters**: Letters display as gradient from yellow (warm) to blue (cold) instead of solid colors
- **Smart Clothing Suggestions**: Based on nippiness score (1-5) from wind-adjusted temperature
- Water recommendation: When temperature > 20°C at either location
- Combines all items in natural language (e.g., "Bring an umbrella, warm coat and scarf, and water")
- Visual indicators with lucide-react icons (Umbrella, ShirtIcon, Droplets)
- Uses MAX nippiness between start and end locations for comprehensive journey preparation
- No "Nippiness Level: X/5" text displayed (cleaner UI)

**Layout Structure (Floating Card Design)**
1. Full-width map (50vh height, edge-to-edge, always visible at top)
   - Header overlay in top-left corner with Settings button (⚙️)
   - Settings button opens dialog for managing saved places
2. Floating search card (overlapping bottom of map) with From/To location inputs
   - White background with shadow for elevation effect
   - Positioned to overlap map by 50% of its height
   - Button text: "How nippy? 🌬️"
3. **Unified NIPPY Component** (single cohesive recommendation display)
   - Large animated letters (N-I-P-P-Y) with temperature-based color gradient:
     * Yellow/gold (warm) → Icy blue (very cold)
     * Letters fill progressively based on nippiness score (1-5)
     * Glow effect and smooth animations
   - Prominent rain warning banner when rain expected (blue callout with Umbrella icon)
   - Icons for all needed items (Umbrella, ShirtIcon, Droplets from lucide-react)
   - Combined recommendation text (e.g., "Bring an umbrella, warm coat and scarf, and water")
   - Wind-adjusted nippiness calculation from both locations
   - Progress bar with color matching nippiness level
4. Weather cards grid (centered container, shows both locations)
5. Saved places section at bottom with "Set as From" / "Set as To" buttons for each saved location

**User Experience**
- Location autocomplete using Nominatim API
- Geolocation support with permission handling
- Real-time weather data from Open-Meteo
- Day/night aware weather icons based on local time
- Responsive design for mobile and desktop
- **Sliding Map Animation**: Map smoothly transitions from 50vh to 15vh when entering locations
  - Smooth CSS transition (500ms ease-in-out)
  - Map stays compressed while interacting with autocomplete
  - Returns to full height only after completing selection
  - No flickering during focus transitions
- **Auto-scroll to Results**: Smooth scroll to recommendations when weather data loads
  - Automatic viewport adjustment after weather check
  - Smooth scrollIntoView animation