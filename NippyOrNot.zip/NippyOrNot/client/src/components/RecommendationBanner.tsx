export interface RecommendationType {
  umbrella: boolean;
  coat: boolean;
  water: boolean;
}

interface RecommendationBannerProps {
  recommendations: RecommendationType;
}

export default function RecommendationBanner({ recommendations }: RecommendationBannerProps) {
  const { umbrella = false, coat = false, water = false } = recommendations || {};
  const allGood = !umbrella && !coat && !water;

  const getTitle = () => {
    if (allGood) return "You're all set to go!";
    
    const items = [];
    if (umbrella) items.push("an umbrella");
    if (coat) items.push("a coat");
    if (water) items.push("water");
    
    if (items.length === 1) {
      return `Bring ${items[0]}`;
    } else if (items.length === 2) {
      return `Bring ${items[0]} and ${items[1]}`;
    } else {
      return `Bring ${items[0]}, ${items[1]}, and ${items[2]}`;
    }
  };

  const getDescription = () => {
    if (allGood) return "Perfect weather conditions at your destinations";
    
    const conditions = [];
    if (umbrella) conditions.push("rain");
    if (coat) conditions.push("cold weather (below 15°C)");
    if (water) conditions.push("warm weather (above 20°C)");
    
    return `${conditions.join(", ")} expected at your destinations`.replace(/,([^,]*)$/, ' and$1');
  };

  return (
    <div className="bg-muted/30 border rounded-md p-6" data-testid="alert-recommendation">
      <div className="flex items-start gap-4">
        <div className="flex gap-3 items-center text-5xl">
          {allGood && (
            <span role="img" aria-label="walking" data-testid="emoji-walking">🚶</span>
          )}
          {umbrella && (
            <span role="img" aria-label="umbrella" data-testid="emoji-umbrella">☂️</span>
          )}
          {coat && (
            <span role="img" aria-label="coat" data-testid="emoji-coat">🧥</span>
          )}
          {water && (
            <span role="img" aria-label="water bottle" data-testid="emoji-water">💧</span>
          )}
        </div>
        <div className="flex-1">
          <p className="text-xl font-semibold text-foreground mb-1" data-testid="text-recommendation-title">
            {getTitle()}
          </p>
          <p className="text-sm text-muted-foreground">
            {getDescription()}
          </p>
        </div>
      </div>
    </div>
  );
}
