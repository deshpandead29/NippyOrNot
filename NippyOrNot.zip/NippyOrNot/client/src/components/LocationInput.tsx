import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Home, Briefcase } from "lucide-react";
import type { SavedPlace } from "@shared/schema";

interface LocationSuggestion {
  place_id: number;
  display_name: string;
  lat: string;
  lon: string;
  name: string;
}

interface LocationInputProps {
  label: string;
  value: string;
  onChange: (value: string, lat?: string, lon?: string) => void;
  placeholder?: string;
  id: string;
  onFocus?: () => void;
  onBlur?: () => void;
}

export default function LocationInput({ 
  label, 
  value, 
  onChange, 
  placeholder = "Enter city name...",
  id,
  onFocus,
  onBlur
}: LocationInputProps) {
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const suppressSearchRef = useRef(false);

  const { data: savedPlaces = [] } = useQuery<SavedPlace[]>({
    queryKey: ['/api/saved-places'],
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current && 
        !dropdownRef.current.contains(event.target as Node) &&
        !inputRef.current?.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    // Abort any previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Skip search if we just selected a location
    if (suppressSearchRef.current) {
      return;
    }

    const searchLocations = async () => {
      if (value.length < 2) {
        setSuggestions([]);
        // Keep dropdown open if there are saved places
        setShowSuggestions(savedPlaces.length > 0);
        return;
      }

      // Create new abort controller for this request
      const controller = new AbortController();
      abortControllerRef.current = controller;

      setLoading(true);
      try {
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?` +
          `q=${encodeURIComponent(value)}&` +
          `format=json&` +
          `limit=5&` +
          `addressdetails=1`,
          { signal: controller.signal }
        );
        
        const data = await response.json();
        
        // Only update if this request wasn't aborted and search not suppressed
        if (!controller.signal.aborted && !suppressSearchRef.current) {
          setSuggestions(data);
          setShowSuggestions(data.length > 0 || savedPlaces.length > 0);
        }
      } catch (error) {
        // Ignore abort errors
        if (error instanceof Error && error.name === 'AbortError') {
          return;
        }
        console.error('Error fetching locations:', error);
        if (!suppressSearchRef.current) {
          setSuggestions([]);
        }
      } finally {
        // Always clear loading state
        setLoading(false);
      }
    };

    const debounceTimer = setTimeout(searchLocations, 300);
    return () => {
      clearTimeout(debounceTimer);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [value, savedPlaces.length]);

  const handleSelect = (suggestion: LocationSuggestion) => {
    // Abort any in-flight requests
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    // Suppress search after selection
    suppressSearchRef.current = true;
    onChange(suggestion.name || suggestion.display_name.split(',')[0], suggestion.lat, suggestion.lon);
    setShowSuggestions(false);
    setSuggestions([]);
  };

  const handleSelectSavedPlace = (place: SavedPlace) => {
    // Abort any in-flight requests
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    // Suppress search after selection
    suppressSearchRef.current = true;
    onChange(place.name, place.latitude.toString(), place.longitude.toString());
    setShowSuggestions(false);
    setSuggestions([]);
  };

  const handleInputChange = (newValue: string) => {
    // Clear suppression when user types
    suppressSearchRef.current = false;
    onChange(newValue);
  };

  const handleSuggestionMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onFocus) {
      onFocus();
    }
  };

  return (
    <div className="space-y-2 relative">
      <Label htmlFor={id} className="text-sm font-medium">
        {label}
      </Label>
      <Input
        ref={inputRef}
        id={id}
        type="text"
        value={value}
        onChange={(e) => handleInputChange(e.target.value)}
        onFocus={() => {
          if (savedPlaces.length > 0) {
            setShowSuggestions(true);
          }
          if (onFocus) onFocus();
        }}
        onBlur={onBlur}
        placeholder={placeholder}
        data-testid={`input-${id}`}
        autoComplete="off"
      />
      
      {showSuggestions && (savedPlaces.length > 0 || suggestions.length > 0) && (
        <Card 
          ref={dropdownRef}
          className="absolute z-50 w-full mt-1 p-1 max-h-64 overflow-y-auto"
          data-testid={`dropdown-${id}`}
        >
          {savedPlaces.length > 0 && (
            <>
              <div className="px-3 py-1 text-xs font-medium text-muted-foreground">
                Saved Places
              </div>
              {savedPlaces.map((place) => {
                const Icon = place.tag === 'home' ? Home : Briefcase;
                return (
                  <button
                    key={place.id}
                    onClick={() => handleSelectSavedPlace(place)}
                    onMouseDown={handleSuggestionMouseDown}
                    className="w-full text-left px-3 py-2 text-sm hover-elevate active-elevate-2 rounded-md flex items-center gap-2"
                    data-testid={`saved-suggestion-${place.tag}`}
                  >
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    <div className="flex-1">
                      <div className="font-medium text-foreground">
                        {place.name}
                      </div>
                      <div className="text-xs text-muted-foreground capitalize">
                        {place.tag}
                      </div>
                    </div>
                  </button>
                );
              })}
              {suggestions.length > 0 && (
                <div className="border-t my-1" />
              )}
            </>
          )}
          {suggestions.map((suggestion) => (
            <button
              key={suggestion.place_id}
              onClick={() => handleSelect(suggestion)}
              onMouseDown={handleSuggestionMouseDown}
              className="w-full text-left px-3 py-2 text-sm hover-elevate active-elevate-2 rounded-md"
              data-testid={`suggestion-${suggestion.place_id}`}
            >
              <div className="font-medium text-foreground">
                {suggestion.name || suggestion.display_name.split(',')[0]}
              </div>
              <div className="text-xs text-muted-foreground truncate">
                {suggestion.display_name}
              </div>
            </button>
          ))}
        </Card>
      )}
      
      {loading && (
        <div className="absolute right-3 top-9 text-xs text-muted-foreground">
          Searching...
        </div>
      )}
    </div>
  );
}
