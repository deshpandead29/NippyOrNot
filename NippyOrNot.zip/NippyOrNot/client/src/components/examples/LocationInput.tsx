import { useState } from 'react';
import LocationInput from '../LocationInput';

export default function LocationInputExample() {
  const [value, setValue] = useState('');

  return (
    <LocationInput 
      id="example-location"
      label="Destination"
      value={value}
      onChange={(val) => setValue(val)}
      placeholder="Enter city..."
    />
  );
}
