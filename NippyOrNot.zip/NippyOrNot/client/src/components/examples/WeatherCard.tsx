import WeatherCard from '../WeatherCard';

export default function WeatherCardExample() {
  const sampleWeather = {
    location: "London",
    temperature: 12,
    feelsLike: 10,
    condition: "Partly Cloudy",
    precipitation: 30,
    humidity: 75,
    windSpeed: 15,
    visibility: 10
  };

  return <WeatherCard weather={sampleWeather} />;
}
