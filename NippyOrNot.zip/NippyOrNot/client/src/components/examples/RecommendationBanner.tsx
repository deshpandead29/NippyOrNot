import RecommendationBanner from '../RecommendationBanner';

export default function RecommendationBannerExample() {
  return (
    <div className="space-y-4">
      <RecommendationBanner type="none" />
      <RecommendationBanner type="umbrella" />
      <RecommendationBanner type="coat" />
      <RecommendationBanner type="both" />
    </div>
  );
}
