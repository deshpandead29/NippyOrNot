import { useEffect, useState } from "react";

interface NippyAnimationProps {
  startTemperature: number;
  endTemperature: number;
  startWindSpeed: number;
  endWindSpeed: number;
  startCondition: string;
  endCondition: string;
  startPrecipitation: number;
  endPrecipitation: number;
}

const CLOTHING_SUGGESTIONS = {
  1: "It is quite pleasant 🌤, a T-shirt or light layers like linen or cotton will do",
  2: "Mild enough 🙂, a jumper or light jacket should be fine",
  3: "Getting nippy 🧥, a coat or thick jacket is recommended",
  4: "Properly chilly 🧣, wear a warm coat and scarf to stay cosy",
  5: "Bitterly cold ❄️, full winter gear including hat, gloves and scarf is advised",
};

const TEMPERATURE_COLORS = {
  1: "rgb(255, 215, 0)",     // Gold/Yellow - warm
  2: "rgb(255, 180, 50)",    // Orange-yellow
  3: "rgb(125, 211, 252)",   // Light cyan
  4: "rgb(96, 165, 250)",    // Blue
  5: "rgb(59, 130, 246)",    // Icy blue - cold
};

export function NippyAnimation({ 
  startTemperature, 
  endTemperature, 
  startWindSpeed, 
  endWindSpeed,
  startCondition,
  endCondition,
  startPrecipitation,
  endPrecipitation
}: NippyAnimationProps) {
  const [currentFill, setCurrentFill] = useState(0);
  const [targetFill, setTargetFill] = useState(0);

  const calculateNippiness = (temp: number, wind: number): number => {
    const windFactor = 0.6 * wind / 10.0;
    const feelsLike = temp - windFactor;

    if (feelsLike > 20) return 1;
    if (feelsLike > 15) return 2;
    if (feelsLike > 10) return 3;
    if (feelsLike > 5) return 4;
    return 5;
  };

  const destNippiness = calculateNippiness(endTemperature, endWindSpeed);
  const maxNippiness = Math.max(
    calculateNippiness(startTemperature, startWindSpeed),
    destNippiness
  );

  const needsUmbrella = 
    (startCondition?.toLowerCase().includes('rain') || false) ||
    (endCondition?.toLowerCase().includes('rain') || false) ||
    startPrecipitation > 40 ||
    endPrecipitation > 40;

  useEffect(() => {
    setCurrentFill(0);
    setTargetFill(maxNippiness);
  }, [maxNippiness]);

  useEffect(() => {
    if (currentFill < targetFill) {
      const interval = setInterval(() => {
        setCurrentFill(prev => {
          const next = prev + 0.08;
          if (next >= targetFill) {
            clearInterval(interval);
            return targetFill;
          }
          return next;
        });
      }, 30);
      return () => clearInterval(interval);
    }
  }, [currentFill, targetFill]);

  const letters = ['N', 'I', 'P', 'P', 'Y'];
  const scoreColor = TEMPERATURE_COLORS[maxNippiness as keyof typeof TEMPERATURE_COLORS];

  const getRecommendationText = () => {
    const clothingSuggestion = CLOTHING_SUGGESTIONS[maxNippiness as keyof typeof CLOTHING_SUGGESTIONS];
    
    if (needsUmbrella) {
      return `Bring an umbrella. ${clothingSuggestion}`;
    }
    
    return clothingSuggestion;
  };

  return (
    <div className="bg-card border rounded-lg p-8 text-center space-y-6" data-testid="container-nippy-animation">
      {needsUmbrella && (
        <div className="bg-blue-50 dark:bg-blue-950 border-2 border-blue-400 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-center gap-3 text-blue-700 dark:text-blue-300">
            <span className="text-6xl" role="img" aria-label="umbrella" data-testid="emoji-umbrella-large">☂️</span>
            <div className="text-left">
              <div className="text-2xl font-bold">Rain Expected!</div>
              <div className="text-lg">Don't forget your umbrella</div>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-center items-center gap-2 mb-4">
        {letters.map((letter, index) => {
          const fillAmount = Math.max(0, Math.min(1, currentFill - index));
          const isFilling = fillAmount > 0 && fillAmount < 1;
          const fillPercentage = fillAmount * 100;
          
          const letterPositions = ['0%', '25%', '50%', '75%', '100%'];

          return (
            <div
              key={index}
              className={`text-7xl font-bold transition-all duration-300 relative ${isFilling ? 'animate-pulse' : ''}`}
              data-testid={`letter-nippy-${index}`}
            >
              <div
                className="absolute inset-0"
                style={{
                  color: 'rgb(100, 100, 120)',
                  opacity: 0.3
                }}
              >
                {letter}
              </div>
              <div
                className="relative"
                style={{
                  backgroundImage: 'linear-gradient(to right, rgb(255, 215, 0) 0%, rgb(255, 180, 50) 25%, rgb(125, 211, 252) 50%, rgb(96, 165, 250) 75%, rgb(59, 130, 246) 100%)',
                  backgroundSize: '500% 100%',
                  backgroundPosition: `${letterPositions[index]} 0%`,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  clipPath: `polygon(0 ${100 - fillPercentage}%, 100% ${100 - fillPercentage}%, 100% 100%, 0 100%)`,
                  filter: fillAmount > 0 ? `drop-shadow(0 0 20px ${scoreColor}40)` : 'none'
                }}
              >
                {letter}
              </div>
            </div>
          );
        })}
      </div>

      <div className="space-y-3">
        <div className="text-lg font-semibold text-foreground" data-testid="text-recommendation-title">
          {getRecommendationText()}
        </div>
      </div>
    </div>
  );
}
