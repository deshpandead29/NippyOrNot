import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Home, Briefcase, GraduationCap, MapPin, X, Plus } from "lucide-react";
import type { SavedPlace } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useState } from "react";

interface SavedPlacesProps {
  onPlaceSelectStart?: (location: string, lat: number, lon: number) => void;
  onPlaceSelectEnd?: (location: string, lat: number, lon: number) => void;
}

export function SavedPlaces({ onPlaceSelectStart, onPlaceSelectEnd }: SavedPlacesProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newPlace, setNewPlace] = useState({
    name: "",
    tag: "home",
    location: "",
    latitude: 0,
    longitude: 0,
  });

  const { data: savedPlaces = [] } = useQuery<SavedPlace[]>({
    queryKey: ["/api/saved-places"],
  });

  const createMutation = useMutation({
    mutationFn: async (place: typeof newPlace) => {
      return await apiRequest("POST", "/api/saved-places", place);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-places"] });
      setIsAddDialogOpen(false);
      setNewPlace({ name: "", tag: "home", location: "", latitude: 0, longitude: 0 });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/saved-places/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-places"] });
    },
  });

  const getIconForTag = (tag: string) => {
    switch (tag) {
      case "home": return <Home className="w-4 h-4" />;
      case "work": return <Briefcase className="w-4 h-4" />;
      case "school": return <GraduationCap className="w-4 h-4" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  const handleAddPlace = () => {
    if (newPlace.location && newPlace.name) {
      createMutation.mutate(newPlace);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto px-4 py-6">
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Saved Places</h3>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-place">
                <Plus className="w-4 h-4 mr-2" />
                Add Place
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Saved Place</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="place-name">Place Name</Label>
                  <Input
                    id="place-name"
                    placeholder="e.g., My Home"
                    value={newPlace.name}
                    onChange={(e) => setNewPlace({ ...newPlace, name: e.target.value })}
                    data-testid="input-place-name"
                  />
                </div>
                <div>
                  <Label htmlFor="place-tag">Tag</Label>
                  <Select
                    value={newPlace.tag}
                    onValueChange={(value) => setNewPlace({ ...newPlace, tag: value })}
                  >
                    <SelectTrigger id="place-tag" data-testid="select-place-tag">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="home">Home</SelectItem>
                      <SelectItem value="work">Work</SelectItem>
                      <SelectItem value="school">School</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="place-location">Location</Label>
                  <Input
                    id="place-location"
                    placeholder="e.g., New York, NY"
                    value={newPlace.location}
                    onChange={(e) => setNewPlace({ ...newPlace, location: e.target.value })}
                    data-testid="input-place-location"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="place-lat">Latitude</Label>
                    <Input
                      id="place-lat"
                      type="number"
                      step="any"
                      placeholder="40.7128"
                      value={newPlace.latitude || ""}
                      onChange={(e) => setNewPlace({ ...newPlace, latitude: parseFloat(e.target.value) || 0 })}
                      data-testid="input-place-latitude"
                    />
                  </div>
                  <div>
                    <Label htmlFor="place-lon">Longitude</Label>
                    <Input
                      id="place-lon"
                      type="number"
                      step="any"
                      placeholder="-74.0060"
                      value={newPlace.longitude || ""}
                      onChange={(e) => setNewPlace({ ...newPlace, longitude: parseFloat(e.target.value) || 0 })}
                      data-testid="input-place-longitude"
                    />
                  </div>
                </div>
                <Button
                  onClick={handleAddPlace}
                  disabled={!newPlace.location || !newPlace.name || createMutation.isPending}
                  className="w-full"
                  data-testid="button-save-place"
                >
                  {createMutation.isPending ? "Saving..." : "Save Place"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {savedPlaces.length === 0 ? (
            <p className="text-muted-foreground text-sm col-span-full text-center py-8">
              No saved places yet. Add your home, work, or school to quickly access them!
            </p>
          ) : (
            savedPlaces.map((place) => (
              <Card
                key={place.id}
                className="p-4 relative group"
                data-testid={`card-saved-place-${place.tag}`}
              >
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteMutation.mutate(place.id);
                  }}
                  data-testid={`button-delete-place-${place.id}`}
                >
                  <X className="w-4 h-4" />
                </Button>
                <div className="flex items-start gap-3 mb-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    {getIconForTag(place.tag)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{place.name}</div>
                    <div className="text-sm text-muted-foreground truncate">
                      {place.location}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1 capitalize">
                      {place.tag}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onPlaceSelectStart?.(place.location, place.latitude, place.longitude)}
                    data-testid={`button-set-from-${place.tag}`}
                  >
                    Set as From
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onPlaceSelectEnd?.(place.location, place.latitude, place.longitude)}
                    data-testid={`button-set-to-${place.tag}`}
                  >
                    Set as To
                  </Button>
                </div>
              </Card>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
