import { useRef, useEffect, useState } from 'react';
import '@tomtom-international/web-sdk-maps/dist/maps.css';
import tt from '@tomtom-international/web-sdk-maps';

interface TomTomMapViewProps {
  startLat?: number;
  startLon?: number;
  endLat?: number;
  endLon?: number;
  currentLat?: number;
  currentLon?: number;
}

export default function TomTomMapView({ 
  startLat, 
  startLon, 
  endLat, 
  endLon,
  currentLat,
  currentLon
}: TomTomMapViewProps) {
  const mapElement = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [apiKey, setApiKey] = useState<string>('');
  const [mapError, setMapError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/config')
      .then(res => res.json())
      .then(data => setApiKey(data.tomtomApiKey))
      .catch(err => console.error('Failed to load TomTom API key:', err));
  }, []);

  useEffect(() => {
    if (!mapElement.current || !apiKey) return;

    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    
    if (!gl) {
      console.warn('WebGL not supported in this browser');
      setMapError('Map preview requires WebGL support');
      return;
    }

    const defaultCenter: [number, number] = currentLat && currentLon 
      ? [currentLon, currentLat]
      : startLat && startLon
      ? [startLon, startLat]
      : [-0.09, 51.505];

    try {
      mapInstance.current = tt.map({
        key: apiKey,
        container: mapElement.current,
        center: defaultCenter,
        zoom: 10,
      });

      setMapError(null);
    } catch (error) {
      console.error('Failed to initialize TomTom map:', error);
      setMapError('Unable to load map');
    }

    return () => {
      if (mapInstance.current) {
        try {
          mapInstance.current.remove();
        } catch (error) {
          console.error('Error removing map:', error);
        }
      }
    };
  }, [apiKey]);

  useEffect(() => {
    if (!mapInstance.current) return;

    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    const bounds = new tt.LngLatBounds();
    let hasMarkers = false;

    if (currentLat && currentLon) {
      const marker = new tt.Marker({ color: '#3378ff' })
        .setLngLat([currentLon, currentLat])
        .addTo(mapInstance.current);
      markersRef.current.push(marker);
      bounds.extend([currentLon, currentLat]);
      hasMarkers = true;
    }

    if (startLat && startLon) {
      const marker = new tt.Marker({ color: '#000000' })
        .setLngLat([startLon, startLat])
        .addTo(mapInstance.current);
      markersRef.current.push(marker);
      bounds.extend([startLon, startLat]);
      hasMarkers = true;
    }

    if (endLat && endLon) {
      const marker = new tt.Marker({ color: '#000000' })
        .setLngLat([endLon, endLat])
        .addTo(mapInstance.current);
      markersRef.current.push(marker);
      bounds.extend([endLon, endLat]);
      hasMarkers = true;
    }

    if (hasMarkers) {
      mapInstance.current.fitBounds(bounds, { padding: 80, maxZoom: 12 });
    }

  }, [currentLat, currentLon, startLat, startLon, endLat, endLon]);

  if (mapError) {
    return (
      <div 
        className="w-full h-full flex items-center justify-center bg-muted/20 border-2 border-dashed border-muted"
        data-testid="container-map-fallback"
      >
        <div className="text-center space-y-2">
          <p className="text-muted-foreground">{mapError}</p>
          <p className="text-sm text-muted-foreground/60">Location markers will appear after selecting destinations</p>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={mapElement} 
      className="w-full h-full"
      data-testid="container-map"
    />
  );
}
