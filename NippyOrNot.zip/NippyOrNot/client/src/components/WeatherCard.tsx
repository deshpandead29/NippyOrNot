import { Card } from "@/components/ui/card";

export interface WeatherData {
  location: string;
  temperature: number;
  feelsLike: number;
  condition: string;
  precipitation: number;
  humidity: number;
  windSpeed: number;
  visibility: number;
  isDay: boolean;
}

interface WeatherCardProps {
  weather: WeatherData;
  loading?: boolean;
}

function getWeatherEmoji(condition: string, isDay: boolean): string {
  const lower = condition.toLowerCase();
  
  if (lower.includes('rain') || lower.includes('drizzle')) {
    return '🌧️';
  }
  if (lower.includes('snow')) {
    return '❄️';
  }
  if (lower.includes('cloud')) {
    return isDay ? '☁️' : '☁️';
  }
  if (lower.includes('clear') || lower.includes('sun')) {
    return isDay ? '☀️' : '🌙';
  }
  if (lower.includes('fog')) {
    return '🌫️';
  }
  if (lower.includes('thunder')) {
    return '⛈️';
  }
  return isDay ? '🌤️' : '🌙';
}

export default function WeatherCard({ weather, loading }: WeatherCardProps) {
  if (loading) {
    return (
      <Card className="p-6">
        <div className="space-y-4 animate-pulse">
          <div className="h-6 bg-muted rounded w-3/4"></div>
          <div className="h-20 bg-muted rounded w-1/2"></div>
          <div className="h-4 bg-muted rounded w-2/3"></div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6" data-testid={`card-weather-${weather.location.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="space-y-6">
        <h3 className="text-xl font-medium text-foreground" data-testid={`text-location-${weather.location.toLowerCase().replace(/\s+/g, '-')}`}>
          {weather.location}
        </h3>

        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <span className="text-5xl" data-testid="emoji-weather-condition" role="img" aria-label={weather.condition}>
              {getWeatherEmoji(weather.condition, weather.isDay)}
            </span>
            <div className="text-5xl font-bold text-foreground" data-testid="text-temperature">
              {Math.round(weather.temperature)}°
            </div>
          </div>
          
          <div>
            <p className="text-base text-foreground" data-testid="text-condition">
              {weather.condition}
            </p>
            <p className="text-sm text-muted-foreground mt-1" data-testid="text-feels-like">
              Feels like {Math.round(weather.feelsLike)}°C
            </p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 pt-4 border-t">
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="text-sm" role="img" aria-label="humidity">💧</span>
              <span className="text-xs text-muted-foreground">Humidity</span>
            </div>
            <div className="text-sm font-medium" data-testid="text-humidity">{weather.humidity}%</div>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="text-sm" role="img" aria-label="wind">💨</span>
              <span className="text-xs text-muted-foreground">Wind</span>
            </div>
            <div className="text-sm font-medium" data-testid="text-wind">{weather.windSpeed} km/h</div>
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-1">
              <span className="text-sm" role="img" aria-label="visibility">👁️</span>
              <span className="text-xs text-muted-foreground">Visibility</span>
            </div>
            <div className="text-sm font-medium" data-testid="text-visibility">{weather.visibility} km</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
