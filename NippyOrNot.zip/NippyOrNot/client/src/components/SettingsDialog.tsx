import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import LocationInput from "@/components/LocationInput";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Home, Briefcase, Trash2 } from "lucide-react";
import type { SavedPlace } from "@shared/schema";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { toast } = useToast();
  const [homeLocation, setHomeLocation] = useState({ name: "", lat: "", lon: "" });
  const [workLocation, setWorkLocation] = useState({ name: "", lat: "", lon: "" });

  const { data: savedPlaces = [] } = useQuery<SavedPlace[]>({
    queryKey: ['/api/saved-places'],
  });

  const homeSaved = savedPlaces.find(p => p.tag === 'home');
  const workSaved = savedPlaces.find(p => p.tag === 'work');

  const saveMutation = useMutation({
    mutationFn: async ({ tag, name, lat, lon }: { tag: string; name: string; lat: string; lon: string }) => {
      // Delete existing place with same tag first
      const existing = savedPlaces.find(p => p.tag === tag);
      if (existing) {
        await apiRequest('DELETE', '/api/saved-places/' + existing.id);
      }

      // Create new place
      return apiRequest('POST', '/api/saved-places', {
        tag,
        name,
        location: name,
        latitude: parseFloat(lat),
        longitude: parseFloat(lon),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/saved-places'] });
      toast({
        title: "Saved successfully",
        description: "Your location has been saved",
      });
      setHomeLocation({ name: "", lat: "", lon: "" });
      setWorkLocation({ name: "", lat: "", lon: "" });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save location",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest('DELETE', '/api/saved-places/' + id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/saved-places'] });
      toast({
        title: "Deleted",
        description: "Saved location removed",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete location",
        variant: "destructive",
      });
    },
  });

  const handleSaveHome = () => {
    if (homeLocation.lat && homeLocation.lon) {
      saveMutation.mutate({ tag: 'home', ...homeLocation });
    }
  };

  const handleSaveWork = () => {
    if (workLocation.lat && workLocation.lon) {
      saveMutation.mutate({ tag: 'work', ...workLocation });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" data-testid="dialog-settings">
        <DialogHeader>
          <DialogTitle>Saved Places</DialogTitle>
          <DialogDescription>
            Save your frequently visited locations for quick access
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Home className="h-4 w-4" />
              <span>Home</span>
            </div>
            {homeSaved ? (
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/50">
                <span className="text-sm" data-testid="text-home-saved">{homeSaved.name}</span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteMutation.mutate(homeSaved.id)}
                  data-testid="button-delete-home"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <LocationInput
                  id="home-location"
                  label=""
                  value={homeLocation.name}
                  onChange={(name, lat, lon) => setHomeLocation({ name, lat: lat || "", lon: lon || "" })}
                  placeholder="Search for home location..."
                  data-testid="input-home-location"
                />
                <Button
                  onClick={handleSaveHome}
                  disabled={!homeLocation.lat || saveMutation.isPending}
                  className="w-full"
                  data-testid="button-save-home"
                >
                  Save Home
                </Button>
              </div>
            )}
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Briefcase className="h-4 w-4" />
              <span>Work</span>
            </div>
            {workSaved ? (
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/50">
                <span className="text-sm" data-testid="text-work-saved">{workSaved.name}</span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteMutation.mutate(workSaved.id)}
                  data-testid="button-delete-work"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <LocationInput
                  id="work-location"
                  label=""
                  value={workLocation.name}
                  onChange={(name, lat, lon) => setWorkLocation({ name, lat: lat || "", lon: lon || "" })}
                  placeholder="Search for work location..."
                  data-testid="input-work-location"
                />
                <Button
                  onClick={handleSaveWork}
                  disabled={!workLocation.lat || saveMutation.isPending}
                  className="w-full"
                  data-testid="button-save-work"
                >
                  Save Work
                </Button>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
