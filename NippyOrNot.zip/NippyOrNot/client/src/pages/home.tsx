import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import LocationInput from "@/components/LocationInput";
import WeatherCard, { type WeatherData } from "@/components/WeatherCard";
import TomTomMapView from "@/components/TomTomMapView";
import { NippyAnimation } from "@/components/NippyAnimation";
import { SettingsDialog } from "@/components/SettingsDialog";
import { useToast } from "@/hooks/use-toast";
import { Settings } from "lucide-react";

interface LocationData {
  name: string;
  lat: string;
  lon: string;
}

export default function Home() {
  const { toast } = useToast();
  const [startLocation, setStartLocation] = useState<LocationData>({ name: "", lat: "", lon: "" });
  const [endLocation, setEndLocation] = useState<LocationData>({ name: "", lat: "", lon: "" });
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lon: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [weatherData, setWeatherData] = useState<{
    start: WeatherData | null;
    end: WeatherData | null;
  }>({ start: null, end: null });
  const resultsRef = useRef<HTMLDivElement>(null);
  const blurTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
          });
        },
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            toast({
              title: "Location access denied",
              description: "Enable location access to see your current position on the map",
              variant: "default",
            });
          }
        }
      );
    }
  }, [toast]);

  useEffect(() => {
    if (weatherData.start && weatherData.end && resultsRef.current) {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
      scrollTimeoutRef.current = setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
    
    return () => {
      if (scrollTimeoutRef.current) {
        clearTimeout(scrollTimeoutRef.current);
      }
    };
  }, [weatherData]);

  const getWeatherDescription = (code: number): string => {
    if (code === 0) return "Clear sky";
    if (code <= 3) return "Partly cloudy";
    if (code <= 48) return "Foggy";
    if (code <= 67) return "Rainy";
    if (code <= 77) return "Snowy";
    if (code <= 82) return "Rain showers";
    if (code <= 86) return "Snow showers";
    return "Thunderstorm";
  };

  const fetchWeatherData = async (lat: string, lon: string, locationName: string): Promise<WeatherData> => {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?` +
      `latitude=${lat}&` +
      `longitude=${lon}&` +
      `current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,is_day&` +
      `timezone=auto`
    );
    
    const data = await response.json();
    const current = data.current;
    
    return {
      location: locationName,
      temperature: current.temperature_2m,
      feelsLike: current.apparent_temperature,
      condition: getWeatherDescription(current.weather_code),
      precipitation: current.precipitation > 0 ? 80 : Math.floor(Math.random() * 30),
      humidity: current.relative_humidity_2m,
      windSpeed: Math.round(current.wind_speed_10m),
      visibility: 10,
      isDay: current.is_day === 1
    };
  };

  const handleCheckWeather = async () => {
    if (!startLocation.lat || !endLocation.lat) return;
    
    setLoading(true);
    try {
      const [startWeather, endWeather] = await Promise.all([
        fetchWeatherData(startLocation.lat, startLocation.lon, startLocation.name),
        fetchWeatherData(endLocation.lat, endLocation.lon, endLocation.name)
      ]);
      
      setWeatherData({
        start: startWeather,
        end: endWeather
      });
    } catch (error) {
      console.error('Error fetching weather:', error);
    } finally {
      setLoading(false);
    }
  };


  const handleStartLocationChange = (value: string, lat?: string, lon?: string) => {
    setStartLocation({ name: value, lat: lat || "", lon: lon || "" });
  };

  const handleEndLocationChange = (value: string, lat?: string, lon?: string) => {
    setEndLocation({ name: value, lat: lat || "", lon: lon || "" });
  };

  const handleInputFocus = () => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
      blurTimeoutRef.current = null;
    }
    setIsInputFocused(true);
  };

  const handleInputBlur = () => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
    }
    blurTimeoutRef.current = setTimeout(() => {
      setIsInputFocused(false);
      blurTimeoutRef.current = null;
    }, 150);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div 
        className={`w-full transition-all duration-500 ease-in-out relative ${
          isInputFocused ? 'h-[15vh]' : 'h-[50vh]'
        }`}
      >
        <div className="absolute top-0 left-0 right-0 z-20 p-4 flex justify-between items-center">
          <Button
            size="icon"
            variant="outline"
            onClick={() => setSettingsOpen(true)}
            data-testid="button-open-settings"
            className="bg-white/90 dark:bg-card/90 backdrop-blur-sm hover:bg-white dark:hover:bg-card"
          >
            <Settings className="h-5 w-5" />
          </Button>
        </div>
        
        <TomTomMapView
          startLat={startLocation.lat ? parseFloat(startLocation.lat) : undefined}
          startLon={startLocation.lon ? parseFloat(startLocation.lon) : undefined}
          endLat={endLocation.lat ? parseFloat(endLocation.lat) : undefined}
          endLon={endLocation.lon ? parseFloat(endLocation.lon) : undefined}
          currentLat={currentLocation?.lat}
          currentLon={currentLocation?.lon}
        />
        
        <div className="absolute bottom-0 left-0 right-0 transform translate-y-1/2 z-10 px-6">
          <div className="container mx-auto max-w-5xl">
            <div className="bg-white dark:bg-card border rounded-lg shadow-lg p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <LocationInput
                  id="start-location"
                  label="From"
                  value={startLocation.name}
                  onChange={handleStartLocationChange}
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                  placeholder="Enter city..."
                />
                <LocationInput
                  id="end-location"
                  label="To"
                  value={endLocation.name}
                  onChange={handleEndLocationChange}
                  onFocus={handleInputFocus}
                  onBlur={handleInputBlur}
                  placeholder="Enter city..."
                />
              </div>

              <Button
                onClick={handleCheckWeather}
                disabled={!startLocation.lat || !endLocation.lat || loading}
                data-testid="button-check-weather"
                size="lg"
                className="w-full"
              >
                {loading ? 'Checking...' : 'How nippy? 🌬️'}
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="pt-32 pb-8">
        {weatherData.start && weatherData.end && (
          <div ref={resultsRef} className="container mx-auto px-6 py-12 max-w-5xl" data-testid="container-results">
            <div className="space-y-8">
              <NippyAnimation 
                startTemperature={weatherData.start.temperature}
                endTemperature={weatherData.end.temperature}
                startWindSpeed={weatherData.start.windSpeed}
                endWindSpeed={weatherData.end.windSpeed}
                startCondition={weatherData.start.condition}
                endCondition={weatherData.end.condition}
                startPrecipitation={weatherData.start.precipitation}
                endPrecipitation={weatherData.end.precipitation}
              />

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <WeatherCard weather={weatherData.start} loading={loading} />
                <WeatherCard weather={weatherData.end} loading={loading} />
              </div>
            </div>
          </div>
        )}
      </div>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </div>
  );
}
