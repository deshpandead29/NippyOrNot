# Weather Travel Companion - Design Guidelines (Notion-Inspired)

## Design Approach

**Selected Approach**: Minimal Notion-Like Design  
**Primary Reference**: Notion's clean, functional aesthetic  
**Justification**: Simple, distraction-free interface with clear hierarchy and spacious layouts. Focus on content over decoration.

## Core Design Principles

1. **Minimal & Clean**: Remove unnecessary visual elements, borders, and shadows
2. **Spacious Layouts**: Generous white space, breathing room between elements
3. **Functional Over Decorative**: Every element serves a purpose
4. **Subtle Interactions**: Hover states are understated, no flashy animations

## Typography System

**Primary Font**: Inter (clean, readable)
**Hierarchy**:
- Page Title: 2xl, semibold
- Location Names: xl, medium
- Temperature: 5xl, bold
- Weather Conditions: base, regular
- Supporting Info: sm, regular
- Muted Text: text-muted-foreground

## Color Palette

**Approach**: Minimal color usage
- Primary actions: Subtle blue/primary
- Backgrounds: White/very light gray in light mode, dark gray in dark mode
- Borders: Extremely subtle, barely visible
- Text: High contrast for readability

## Layout System

**Spacing**: Consistent, generous spacing
- Container padding: p-6 to p-8
- Section gaps: gap-8 to gap-12
- Card padding: p-6
- Minimal tight spacing

**Grid Structure**:
- Single column on mobile
- Two column for weather cards on desktop
- Max width: 5xl centered
- Clean alignment, no complex grids

## Component Library

### Header
- Simple text title, no fancy styling
- Clean, minimal top bar
- Theme toggle on the right

### Location Input
- Clean input fields with subtle borders
- Autocomplete dropdown: Simple white card with hover states
- No icons unless necessary
- Focus: subtle ring, no color changes

### Weather Cards
- Minimal card design with subtle border
- Generous internal padding
- Clean typography hierarchy
- Icon: Simple, monochrome
- No heavy shadows or gradients

### Recommendation Banner
- Subtle background tint
- Simple icon + text
- No aggressive styling

## Interaction Patterns

- **Hover**: Subtle background change only
- **Loading**: Simple skeleton, no spinners
- **Transitions**: Quick, subtle (100-200ms)
- **No animations**: Keep it static and fast

## Responsive Breakpoints

- Mobile: Single column, full width
- Desktop (lg): Two columns for weather cards

## Critical Elements

- Clean, readable typography
- Generous spacing throughout
- Minimal visual decoration
- Fast, functional interactions
