# NIPPY Animation Module

A self-contained Python Pygame module that creates an animated visualization of the word "NIPPY" based on weather conditions.

## Features

- **Wind-Adjusted Nippiness Score**: Calculates a score from 1-5 based on temperature and wind speed
- **Smooth Letter Animation**: Letters fill progressively based on the nippiness score
- **Clothing Recommendations**: Shows appropriate clothing for each nippiness level
- **Self-Contained**: Runs on its own surface, safe to import into existing Pygame apps
- **Visual Design**: Bright cyan letters on dark background with smooth animations

## Nippiness Score System

The module uses a wind-adjusted "feels-like" formula:

```
feels_like = temperature - (0.6 × wind_speed / 10)
```

**Score Levels:**
- **Score 1** (feels-like > 20°C): T-shirt/light layers
- **Score 2** (feels-like > 15°C): Jumper/light jacket
- **Score 3** (feels-like > 10°C): Coat/thick jacket
- **Score 4** (feels-like > 5°C): Warm coat+scarf
- **Score 5** (feels-like ≤ 5°C): Winter coat+hat, gloves, scarf

## Installation

```bash
pip install pygame
```

Or using uv (in Replit):
```bash
uv add pygame
```

## Standalone Usage

Run the demo directly:

```bash
python nippy_animation.py
```

The demo will automatically cycle through different weather conditions every 4 seconds, showing how the animation responds to different temperatures and wind speeds.

**Controls:**
- `SPACE`: Manually cycle to next weather condition
- `ESC`: Quit

## Integration into Your Pygame App

```python
import pygame
from nippy_animation import NippyAnimator

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()

# Create the NIPPY animator
nippy = NippyAnimator(800, 600)
nippy.setup()

# Set weather conditions
nippy.set_conditions(temperature=8.0, wind_speed=20.0)  # Cold and windy!

# Game loop
running = True
while running:
    dt = clock.tick(60) / 1000.0
    
    # Update animation
    nippy.update(dt)
    
    # Draw to screen
    surface = nippy.draw()
    screen.blit(surface, (0, 0))
    
    pygame.display.flip()
```

## API Reference

### `NippyAnimator(width=800, height=600)`

Creates a new NIPPY animator instance.

**Parameters:**
- `width`: Surface width in pixels (default: 800)
- `height`: Surface height in pixels (default: 600)

### Methods

#### `setup()`
Initialize fonts and resources. Must be called after `pygame.init()`.

#### `set_conditions(temperature, wind_speed)`
Update weather conditions and recalculate nippiness score.

**Parameters:**
- `temperature`: Temperature in Celsius
- `wind_speed`: Wind speed in km/h

**Example:**
```python
nippy.set_conditions(temperature=12.0, wind_speed=15.0)
```

#### `update(dt)`
Update animation state. Call this every frame.

**Parameters:**
- `dt`: Delta time in seconds since last update

#### `draw()`
Render the animation to the surface.

**Returns:**
- `pygame.Surface`: The rendered surface

#### `calculate_nippiness(temperature, wind_speed)`
Calculate nippiness score from conditions.

**Parameters:**
- `temperature`: Temperature in Celsius
- `wind_speed`: Wind speed in km/h

**Returns:**
- `int`: Score from 1 (pleasant) to 5 (very nippy)

## Visual Elements

The animation displays:

1. **NIPPY Letters**: Large letters that fill progressively (left to right)
   - Empty: Dark gray outline
   - Filling: Pulsing bright cyan
   - Filled: Solid bright cyan

2. **Weather Info**: Current temperature and wind speed

3. **Nippiness Score**: Numerical score out of 5

4. **Clothing Recommendation**: Text suggestion for appropriate clothing

5. **Progress Bar**: Visual indicator showing fill level (0-5)

## Animation Behavior

- Letters fill at a rate of 2 letters per second
- Currently filling letter pulses to draw attention
- Smooth transitions when conditions change
- Progress bar with segment markers for each level

## Example Conditions

```python
# Pleasant summer day
nippy.set_conditions(25.0, 5.0)  # Score: 1

# Mild autumn day
nippy.set_conditions(17.0, 10.0)  # Score: 2

# Cool day with breeze
nippy.set_conditions(12.0, 15.0)  # Score: 3

# Cold and windy
nippy.set_conditions(7.0, 20.0)  # Score: 4

# Winter conditions
nippy.set_conditions(2.0, 25.0)  # Score: 5
```

## Files

- `nippy_animation.py` - Main module with NippyAnimator class
- `example_nippy_usage.py` - Simple integration example
- `NIPPY_ANIMATION_README.md` - This documentation

## Notes

- The module uses its own surface, so it won't interfere with other Pygame elements
- All rendering is done to `animator.surface` which you can blit anywhere
- Font initialization happens in `setup()` to avoid conflicts
- Colors and animation speed can be customized by modifying class constants

## License

Free to use and modify for your projects!
