import { type User, type InsertUser, type SavedPlace, type InsertSavedPlace } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllSavedPlaces(): Promise<SavedPlace[]>;
  getSavedPlacesByTag(tag: string): Promise<SavedPlace[]>;
  createSavedPlace(place: InsertSavedPlace): Promise<SavedPlace>;
  deleteSavedPlace(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private savedPlaces: Map<string, SavedPlace>;

  constructor() {
    this.users = new Map();
    this.savedPlaces = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllSavedPlaces(): Promise<SavedPlace[]> {
    return Array.from(this.savedPlaces.values());
  }

  async getSavedPlacesByTag(tag: string): Promise<SavedPlace[]> {
    return Array.from(this.savedPlaces.values()).filter(
      (place) => place.tag === tag,
    );
  }

  async createSavedPlace(insertPlace: InsertSavedPlace): Promise<SavedPlace> {
    const id = randomUUID();
    const place: SavedPlace = { ...insertPlace, id };
    this.savedPlaces.set(id, place);
    return place;
  }

  async deleteSavedPlace(id: string): Promise<boolean> {
    return this.savedPlaces.delete(id);
  }
}

export const storage = new MemStorage();
