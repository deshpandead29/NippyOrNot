import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSavedPlaceSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/config", (_req, res) => {
    res.json({
      tomtomApiKey: process.env.TOMTOM_API_KEY || '',
    });
  });

  app.get("/api/saved-places", async (_req, res) => {
    try {
      const places = await storage.getAllSavedPlaces();
      res.json(places);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch saved places" });
    }
  });

  app.post("/api/saved-places", async (req, res) => {
    try {
      const validatedPlace = insertSavedPlaceSchema.parse(req.body);
      const newPlace = await storage.createSavedPlace(validatedPlace);
      res.json(newPlace);
    } catch (error) {
      res.status(400).json({ error: "Invalid place data" });
    }
  });

  app.delete("/api/saved-places/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteSavedPlace(req.params.id);
      if (deleted) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Place not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete place" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
